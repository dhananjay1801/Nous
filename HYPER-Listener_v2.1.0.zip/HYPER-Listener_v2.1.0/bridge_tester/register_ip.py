import socket
import requests
import json
from datetime import datetime

def get_all_local_ips():
    """Get all local IP addresses of the machine"""
    try:
        hostname = socket.gethostname()
        local_ips = set()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ip.startswith('192.168.') or ip.startswith('10.') or ip.startswith('172.'):
                local_ips.add(ip)
        return list(local_ips)
    except Exception as e:
        print(f"[!] Error getting all local IPs: {e}")
        return []

def get_public_ip():
    """Get the public IP address of the machine"""
    try:
        response = requests.get('https://api.ipify.org?format=json', timeout=5)
        return response.json()['ip']
    except Exception as e:
        print(f"[!] Error getting public IP: {e}")
        return None

def register_ip_with_api(ip_address, api_base_url):
    try:
        url = f"{api_base_url}/register_ip"
        data = {'ip_address': ip_address}
        response = requests.post(url, json=data, timeout=10)
        if response.status_code == 200:
            result = response.json()
            print(f"[+] Registered IP {ip_address} | Hashcode: {result.get('hashcode', 'N/A')}")
            return True
        else:
            print(f"[!] API error: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"[!] Error registering IP with API: {e}")
        return False

def main(api_base_url):
    print("[*] Registering all available IP addresses via API...")
    success_count = 0
    registered_ips = []
    all_local_ips = get_all_local_ips()
    if all_local_ips:
        print(f"[*] Found {len(all_local_ips)} local IP(s): {', '.join(all_local_ips)}")
        for ip in all_local_ips:
            if register_ip_with_api(ip, api_base_url):
                success_count += 1
                registered_ips.append(ip)
    public_ip = get_public_ip()
    if public_ip and public_ip not in registered_ips:
        print(f"[*] Public IP: {public_ip}")
        if register_ip_with_api(public_ip, api_base_url):
            success_count += 1
            registered_ips.append(public_ip)
    if success_count > 0:
        print(f"[+] Successfully registered {success_count} IP address(es): {', '.join(registered_ips)}")
    else:
        print("[!] Failed to register any IP addresses")

if __name__ == "__main__":
    # Change this to your Nous app's IP and port
    API_BASE_URL = 'http://enter_here' # Enter host pc's ip with :5000 as port
    main(API_BASE_URL) 